"""
data_utils.py

Utility functions for loading the small CAFA-6 sample dataset and
creating train/validation DataLoaders for the demo notebook.
"""

from typing import Tuple

import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split


def load_sample_data(path: str = "data/sample_data.npz"):
    """
    Load the pre-computed sample dataset used in the demo notebook.

    Parameters
    ----------
    path : str
        Path to the compressed NumPy (.npz) file with keys:
        - "X": protein embeddings, shape (N, D)
        - "Y": multi-label targets, shape (N, L)
        - "ids": protein IDs (e.g., UniProt IDs), shape (N,)
        - "go_terms": GO term strings, shape (L,)

    Returns
    -------
    X : np.ndarray, float32
    Y : np.ndarray, float32
    protein_ids : np.ndarray
    go_terms : np.ndarray
    """
    data = np.load(path, allow_pickle=True)

    X = data["X"].astype(np.float32)
    Y = data["Y"].astype(np.float32)
    protein_ids = data["ids"]
    go_terms = data["go_terms"]

    return X, Y, protein_ids, go_terms


def make_dataloaders(
    X: np.ndarray,
    Y: np.ndarray,
    batch_size: int = 128,
    val_size: float = 0.3,
    random_state: int = 42,
):
    """
    Split data into train/validation sets and wrap them in PyTorch DataLoaders.

    Parameters
    ----------
    X : np.ndarray
        Embeddings of shape (N, D).
    Y : np.ndarray
        Multi-label targets of shape (N, L).
    batch_size : int
        Batch size for the DataLoaders.
    val_size : float
        Fraction of data used for validation.
    random_state : int
        Random seed for the train/validation split.

    Returns
    -------
    (X_train, X_val, Y_train, Y_val) : tuple of np.ndarray
    (train_loader, val_loader) : tuple of DataLoader
    """
    X_train, X_val, Y_train, Y_val = train_test_split(
        X, Y, test_size=val_size, random_state=random_state, shuffle=True
    )

    X_train_t = torch.tensor(X_train, dtype=torch.float32)
    Y_train_t = torch.tensor(Y_train, dtype=torch.float32)
    X_val_t = torch.tensor(X_val, dtype=torch.float32)
    Y_val_t = torch.tensor(Y_val, dtype=torch.float32)

    train_ds = TensorDataset(X_train_t, Y_train_t)
    val_ds = TensorDataset(X_val_t, Y_val_t)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    return (X_train, X_val, Y_train, Y_val), (train_loader, val_loader)
