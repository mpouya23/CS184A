"""
predict_utils.py

Helpers for inspecting model predictions on individual proteins
from the validation set.
"""

from typing import Dict, Optional, Sequence

import numpy as np
import torch
import torch.nn as nn


def predict_single(
    model: nn.Module,
    X_val: np.ndarray,
    Y_val: np.ndarray,
    protein_ids: Sequence,
    go_terms: Sequence,
    device: torch.device,
    idx: Optional[int] = None,
    threshold: float = 0.5,
    top_k: int = 5,
) -> Dict:
    """
    Inspect predictions for a single protein in the validation set.

    Parameters
    ----------
    model : nn.Module
        Trained GOModelSmall model.
    X_val : np.ndarray
        Validation embeddings, shape (N_val, D).
    Y_val : np.ndarray
        Validation labels, shape (N_val, L).
    protein_ids : sequence
        Sequence of protein IDs aligned with X/Y.
    go_terms : sequence
        Sequence of GO term strings aligned with label indices.
    device : torch.device
        Device used for inference.
    idx : int, optional
        Index of the protein in the validation set. If None, a random index is chosen.
    threshold : float
        Probability threshold for selecting predicted GO terms.
    top_k : int
        Fallback number of top-scoring GO terms if none exceed the threshold.

    Returns
    -------
    dict
        Dictionary with keys:
            - "protein_id"
            - "true_terms"
            - "predicted_terms"
            - "predicted_probs"
    """
    model.eval()

    if idx is None:
        idx = np.random.randint(0, X_val.shape[0])

    x_example = X_val[idx : idx + 1]
    y_true = Y_val[idx]
    pid = protein_ids[idx]

    with torch.no_grad():
        logits = model(torch.tensor(x_example, dtype=torch.float32).to(device))
        probs = torch.sigmoid(logits).cpu().numpy()[0]

    pred_idx = np.where(probs >= threshold)[0]
    if len(pred_idx) == 0:
        pred_idx = np.argsort(-probs)[:top_k]

    true_idx = np.where(y_true > 0.5)[0]

    true_terms = [go_terms[i] for i in true_idx]
    pred_terms = [go_terms[i] for i in pred_idx]
    pred_probs = [float(probs[i]) for i in pred_idx]

    return {
        "protein_id": pid,
        "true_terms": true_terms,
        "predicted_terms": pred_terms,
        "predicted_probs": pred_probs,
    }
