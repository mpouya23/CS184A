"""
train_utils.py

Training and evaluation helpers for the GOModelSmall network.
"""

from typing import Dict, List

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score


def evaluate(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    threshold: float = 0.5,
) -> float:
    """
    Evaluate a model on a DataLoader using micro-F1.

    Parameters
    ----------
    model : nn.Module
        Trained PyTorch model.
    loader : DataLoader
        DataLoader for validation or test data.
    device : torch.device
        Device on which the model and data reside.
    threshold : float
        Probability threshold to binarize predictions.

    Returns
    -------
    float
        Micro-averaged F1 score over all labels.
    """
    model.eval()
    all_probs = []
    all_true = []

    with torch.no_grad():
        for Xb, Yb in loader:
            Xb = Xb.to(device)
            logits = model(Xb)
            probs = torch.sigmoid(logits).cpu().numpy()
            all_probs.append(probs)
            all_true.append(Yb.numpy())

    probs = np.concatenate(all_probs, axis=0)
    true = np.concatenate(all_true, axis=0)

    pred_bin = (probs >= threshold).astype(int)
    f1 = f1_score(true, pred_bin, average="micro", zero_division=0)

    return f1


def train(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    device: torch.device,
    epochs: int = 3,
    lr: float = 1e-3,
    save_path: str = "best_model_small.pth",
) -> Dict[str, List[float]]:
    """
    Train a GOModelSmall model for a few epochs and track metrics.

    Parameters
    ----------
    model : nn.Module
        Model to train.
    train_loader : DataLoader
        DataLoader for the training split.
    val_loader : DataLoader
        DataLoader for the validation split.
    device : torch.device
        CPU or GPU.
    epochs : int
        Number of training epochs.
    lr : float
        Learning rate for Adam optimizer.
    save_path : str
        Path where the best model parameters are saved.

    Returns
    -------
    history : dict
        Dictionary with keys "train_loss" and "val_f1", each a list per epoch.
    """
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    history = {"train_loss": [], "val_f1": []}
    best_f1 = 0.0

    model.to(device)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0

        for Xb, Yb in train_loader:
            Xb = Xb.to(device)
            Yb = Yb.to(device)

            optimizer.zero_grad()
            logits = model(Xb)
            loss = criterion(logits, Yb)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        val_f1 = evaluate(model, val_loader, device=device, threshold=0.5)
        history["train_loss"].append(total_loss)
        history["val_f1"].append(val_f1)

        print(f"Epoch {epoch}/{epochs} | "
              f"Train loss: {total_loss:.4f} | "
              f"Val micro-F1: {val_f1:.4f}")

        if val_f1 > best_f1:
            best_f1 = val_f1
            torch.save(model.state_dict(), save_path)
            print(f"  ✓ New best model saved to {save_path}")

    return history
