"""
model.py

Neural network model for multi-label protein function prediction
from precomputed ESM2 embeddings.
"""

from typing import Optional

import torch
import torch.nn as nn


class GOModelSmall(nn.Module):
    """
    A small feed-forward neural network for multi-label GO term prediction.

    Architecture:
        Input (D)
        → Linear(D, hidden_dim)
        → ReLU
        → Dropout
        → Linear(hidden_dim, output_dim)
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 256,
        output_dim: int = 300,
        dropout: float = 0.3,
    ):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Parameters
        ----------
        x : torch.Tensor
            Input tensor of shape (batch_size, input_dim).

        Returns
        -------
        torch.Tensor
            Logits of shape (batch_size, output_dim).
        """
        return self.net(x)
