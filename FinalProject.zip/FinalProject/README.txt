Folder highlights
Project for Protein Function Prediction uses deep learning with ESM2 embeddings and includes code for model training and evaluation on a small CAFA-6 sample.

Project Title: Protein Function Prediction for CAFA-6
Student: Melina Pouya
Course: CS 184A/284A – Fall 2025
Files included in this project folder: project/

------------------------------------------------------------
1. Purpose of the Project
------------------------------------------------------------
This project predicts Gene Ontology (GO) protein functions using
deep learning and precomputed ESM2 embeddings. Proteins are
represented as FASTA sequences and converted into 320-dimensional
embeddings using the ESM2-T6-8M model. A feed-forward neural
network is trained to predict protein functions in a multi-label
classification setting (thousands of GO terms in the full project;
a reduced label set is used in this demo for speed and size limits).

------------------------------------------------------------
2. Description of Files
------------------------------------------------------------

project.ipynb
    - Main demo notebook. Loads a small sample dataset, trains a
      compact neural network, evaluates micro-F1, and shows example
      GO term predictions in under 1 minute.

project.html
    - HTML export of project.ipynb showing all code cells and
      outputs without needing to re-run the notebook.

README.txt
    - This file. Describes the purpose of the project and each file
      in the project/ directory.

data/
    - Directory containing lightweight sample data used by the demo.

data/sample_data.npz
    - Compressed NumPy file with precomputed ESM2 embeddings,
      multi-label GO targets, protein IDs, and GO term names
      (kept under 5 MB as required).

src/
    - Directory with Python source code used conceptually by the
      notebook (helper modules for data, model, training, and
      prediction).

src/__init__.py
    - Marks src/ as a Python package and documents the helper
      modules available for the project.

src/data_utils.py
    - Utility functions for loading data/sample_data.npz and
      creating train/validation PyTorch DataLoaders.

src/model.py
    - Defines the GOModelSmall feed-forward neural network
      (Linear → ReLU → Dropout → Linear) for multi-label GO
      prediction from 320-dim ESM2 embeddings.

src/train_utils.py
    - Training loop and evaluation helpers, including computation
      of micro-F1 and saving the best-performing model to disk.

src/predict_utils.py
    - Helper function to inspect single-protein predictions by
      listing true and predicted GO terms and their probabilities.

models/
    - Directory for saved model weights used in the demo.

models/best_model_small.pth
    - Saved state_dict for the best GOModelSmall network found
      during training in project.ipynb.

------------------------------------------------------------
3. How to Run project.ipynb
------------------------------------------------------------
1. Open project.ipynb in Jupyter, VS Code, or Google Colab.
2. Ensure the working directory is the project/ folder so that
   "data/sample_data.npz" and "src/" can be found.
3. Run all cells from top to bottom.

The notebook:
   – Loads sample_data.npz (ESM2 embeddings + GO labels + IDs)
   – Splits the data into train/validation sets
   – Builds and trains a small feed-forward neural network
   – Computes validation micro-F1 using a fixed threshold
   – Visualizes training loss and validation performance
   – Shows example true vs. predicted GO terms for one protein

Runtime: designed to complete in well under 1 minute.

------------------------------------------------------------
4. Dependencies
------------------------------------------------------------
Python 3.9+
PyTorch
NumPy
Pandas
scikit-learn
matplotlib

(For the full project, ESM2 embeddings were generated using the
fair-esm library, but in this demo all embeddings are precomputed
and stored in data/sample_data.npz, so fair-esm is not required to
run the notebook.)

------------------------------------------------------------
5. Notes
------------------------------------------------------------
- The full CAFA-6 training and evaluation datasets are NOT included
  due to size limits.
- The sample_data.npz file is a small, representative subset of the
  full data, created to keep the project.zip submission small and
  fast to run.
- The saved weights in models/best_model_small.pth were obtained by
  training on this sample and are used to illustrate predictions in
  the notebook.
